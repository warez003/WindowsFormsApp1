﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Load += Load_Event;
        }

        unsafe private void Load_Event(object sender, EventArgs e)
        {
            this.Text = "Test_Editor3000";
            this.Width = 800; this.Height = 600;
            this.CenterToScreen();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.AutoScroll = true;
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;

            List<Button> bt = new List<Button>();

            Label lb1 = Create_Label(this, "lb1", "Создавай тесты просто!", new Point(this.Width/2, this.Height/2));
            lb1.Location = new Point(this.Width / 2 - lb1.Width / 2 - 70 , this.Height / 2 - lb1.Height / 2 - 50);
            lb1.Font = new Font("Times new roman", 18, FontStyle.Regular);
            lb1.ForeColor = Color.FromArgb(65, 105, 225);

            Button bt1 = Create_Button(this, "bt_edit_bio", "Создать тест", new Point(lb1.Location.X + lb1.Width / 2, lb1.Location.Y + lb1.Height + 10));
            bt1.Location = new Point(lb1.Location.X + lb1.Width / 2 - bt1.Width / 2, lb1.Location.Y + lb1.Height + 10);
            bt.Add(bt1);
            bt1.BackColor = Color.FromArgb(65, 105, 225);

            for (int i = 0; i < bt.Count; i++)
            {
                bt[i].Click += Button_Click;
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            if (b.Name == "bt_add_results")
            {
                progressBar1.Value++;
                Edit_Results(progressBar1.Value);
            }
            if (b.Name == "bt_edit_bio")
            {
                this.Controls.Clear();

                Label lb2 = Create_Label(this, "lb2", "Создание теста: название и описание", this.Location);
                lb2.Font = new Font("Times new roman", 20, FontStyle.Regular);
                lb2.ForeColor = Color.FromArgb(65, 105, 225);
                lb2.Dock = DockStyle.Top | DockStyle.Fill; lb2.Anchor = AnchorStyles.Left | AnchorStyles.Top;
                comboBox1.Items.Add(lb2.Name);

                Label lb3 = Create_Label(this, "lb3", "Название теста: ", new Point(lb2.Location.X + 10, lb2.Location.Y + lb2.Height + 10));

                TextBox tb1 = Create_TextBox(this, "tb1", new Point(lb3.Location.X + 100, lb3.Location.Y), new Size(Convert.ToInt32(this.Width / 1.4), 20));

                Label lb4 = Create_Label(this, "lb4", "Описание теста: ", new Point(lb3.Location.X, lb3.Location.Y + lb3.Size.Height + 15));

                TextBox tb2 = Create_TextBox(this, "tb2", new Point(lb4.Location.X, lb4.Location.Y + 25), new Size(Convert.ToInt32(this.Width / 1.2), this.Height / 4));

                Button bt2 = Create_Button(this, "bt_edit_questions", "Перейти к редактированию вопросов", new Point(tb2.Location.X + tb2.Size.Width / 2 - lb4.Width, tb2.Location.Y + tb2.Size.Height + 10));
                bt2.BackColor = Color.FromArgb(65, 105, 225);
                bt2.Click += Button_Click;
            }
            if (b.Name == "bt_edit_questions")
            {
                this.Controls.Clear();

                Label lb5 = Create_Label(this, "lb5", "Редактирование теста: вопросы и баллы за них", this.Location);
                lb5.Font = new Font("Times new roman", 16, FontStyle.Regular);
                lb5.ForeColor = Color.FromArgb(65, 105, 225);
                lb5.Dock = DockStyle.Top; lb5.Anchor = AnchorStyles.Left | AnchorStyles.Top;

                Gen_Panel(1);
            }
            if (b.Name == "btsave")
            {
                this.Controls.Clear();

                Label lb11 = Create_Label(this, "lb11", "Сохранение теста: название и описание", this.Location);
                lb11.Font = new Font("Times new roman", 20, FontStyle.Regular);
                lb11.ForeColor = Color.FromArgb(65, 105, 225);
                lb11.Dock = DockStyle.Top; lb11.Anchor = AnchorStyles.Left | AnchorStyles.Top;

                Label lb33 = Create_Label(this, "lb33", "Название теста: ", new Point(lb11.Location.X, Convert.ToInt32(lb11.Location.Y + lb11.Height / 1.5) + 10));

                TextBox tbt = Create_TextBox(this, "tbb", new Point(lb33.Location.X + lb33.Width + 5, lb33.Location.Y), new Size(Convert.ToInt32(lb11.Size.Width / 1.3), 20));

                Label lb13 = Create_Label(this, "lb13", "Описание теста: ", new Point(lb33.Location.X, lb33.Location.Y + lb11.Height));

                TextBox tb9 = Create_TextBox(this, "tb9", new Point(lb13.Location.X + 35, lb13.Location.Y + 20), new Size(Convert.ToInt32(this.Width / 1.2), this.Height / 4));

                Button bt10 = Create_Button(this, "bt_edit_questions", "Перейти к редактированию вопросов", new Point(tb9.Location.X + tb9.Width / 2, tb9.Location.Y + tb9.Size.Height + 10));
                bt10.Location = new Point(tb9.Location.X + tb9.Width / 2 - bt10.Width / 2, tb9.Location.Y + tb9.Size.Height + 10);
                bt10.BackColor = Color.FromArgb(65, 105, 225);
                bt10.Click += Button_Click;

                Button bt11 = Create_Button(this, "btresult", "Перейти к редактированию результатов", new Point(bt10.Location.X - 5, bt10.Location.Y + bt10.Size.Height + 10));
                bt11.BackColor = Color.FromArgb(65, 105, 225);
                bt11.Click += Button_Click;

                Button _save = Create_Button(this, "_save", "Сохранить данные", new Point(bt11.Location.X, bt11.Location.Y + bt11.Height));
                _save.Location = new Point(bt11.Location.X + _save.Width / 2, bt11.Location.Y + bt11.Height + 10);
                _save.Click += Button_Click;
            }
            if (b.Name == "_save")
            {
                Save_Files();
            }
            if (b.Name == "add_questions")
            {
                progressBar1.Value++;
                Gen_Panel(progressBar1.Value);
            }
            if (b.Name == "btresult")
            {
                this.Controls.Clear();

                Label lbl = Create_Label(this, "lbl", "Создание теста: название и описание", new Point(this.Width / 2 - 390, this.Height / 3 - 520));
                lbl.Font = new Font("Times new roman", 18, FontStyle.Regular);
                lbl.ForeColor = Color.FromArgb(65, 105, 225);
                lbl.Dock = DockStyle.Left; lbl.Anchor = AnchorStyles.Top | AnchorStyles.Left;
                lbl.Visible = false;

                Button bt6 = Create_Button(this, "bt_edit_bio", "Перейти к редактированию описания", new Point(lbl.Location.X, lbl.Location.Y + 5));
                bt6.Location = new Point(lbl.Location.X + lbl.Width / 2 + bt6.Width / 4 - lbl.Width/2 + bt6.Width/4, lbl.Location.Y + lbl.Height + 10);
                bt6.BackColor = Color.FromArgb(65, 105, 225);
                bt6.Click += Button_Click;

                Button bt7 = Create_Button(this, "bt_edit_questions", "Перейти к редактированию вопросов", new Point(bt6.Location.X, bt6.Location.Y + bt6.Size.Height + 10));
                bt7.BackColor = Color.FromArgb(65, 105, 225);
                bt7.Click += Button_Click;

                Edit_Results(1);

            }
            if(b.Name == "bt_add_variants")
            {
                progressBar1.Value++;

                if (progressBar1.Value == 8)
                {
                    b.Hide();
                }

                Gen_Variants(progressBar1.Value);
            }


        }
        
        private void Gen_Variants (int k = 0)
        {

            int h1 = k * 25;

            Label label = Create_Label(this, "label", "Вариант ответа:", new Point(this.Width / 2 - 390, this.Height / 3 - 40 + h1));
            TextBox textBox = Create_TextBox(this, "textBox", new Point(label.Location.X + label.Width, label.Location.Y), new Size(Convert.ToInt32(this.Size.Width / 1.6) - 35, 20));
            Label label2 = Create_Label(this, "label2", "Баллы", new Point(textBox.Location.X + textBox.Width, textBox.Location.Y));
            TextBox textBox2 = Create_TextBox(this, "textBox2", new Point(label2.Location.X + label2.Width, label2.Location.Y), new Size(label2.Width, 20));
        }

        private void Save_Files()
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*"; saveFile.CreatePrompt = true; saveFile.OverwritePrompt = true; saveFile.DefaultExt = ".txt"; saveFile.Title = "Сохранение данных программы"; saveFile.AddExtension = true; saveFile.DefaultExt = ".txt";

            if (saveFile.ShowDialog() == DialogResult.Cancel)
                return;

            string filename = saveFile.FileName;
            System.IO.File.WriteAllText(filename, _data.Text);
            MessageBox.Show("Сохранение произошло успешно!");
        }

        public void Edit_Results(int k = 0)
        {
            int h1 = k * 300;

            Label label = Create_Label(this, "label", "Результат для суммы баллов от", new Point(this.Width / 2 - 390, this.Height / 3 - 390 + h1));

            TextBox textBox = Create_TextBox(this, "textBox", new Point(label.Location.X + label.Size.Width, label.Location.Y), new Size(label.Size.Width / 4, 20));

            Label label2 = Create_Label(this, "label2", "до", new Point(textBox.Location.X + textBox.Size.Width, textBox.Location.Y));

            TextBox textBox1 = Create_TextBox(this, "textBox1", new Point(label2.Location.X + label2.Width, label2.Location.Y), new Size(label.Size.Width / 4, 20));

            Label label3 = Create_Label(this, "label3", "Заголовок:", new Point(label.Location.X, label.Location.Y + label.Size.Height + 10));

            TextBox textBox2 = Create_TextBox(this, "textBox2", new Point(label3.Location.X + label3.Size.Width, label3.Location.Y), new Size(Convert.ToInt32(this.Size.Width / 1.6) - 35, 20));

            Label label4 = Create_Label(this, "label4", "Описание:", new Point(label3.Location.X, label3.Location.Y + label3.Size.Height + 10));

            TextBox textBox3 = Create_TextBox(this, "textBox3", new Point(label4.Location.X + 10, label4.Location.Y + label4.Height + 5), new Size(Convert.ToInt32(this.Size.Width / 1.2) - 35, this.Height / 6));

            Button button1 = Create_Button(this, "bt_add_results", "Добавить еще результат", new Point(textBox3.Location.X, textBox3.Location.Y + textBox3.Height + 5));
            button1.Location = new Point(textBox3.Location.X - button1.Width / 2 + textBox3.Width / 2, textBox3.Location.Y + textBox3.Height + 5);
            button1.ForeColor = Color.FromArgb(65, 105, 225);
            button1.Click += Button_Click;

            Button button2 = Create_Button(this, "btsave", "Сохранить тест", new Point(button1.Location.X, button1.Location.Y + button1.Height + 5));
            button2.Location = new Point(button1.Location.X + button2.Width - button1.Width / 2, button1.Location.Y + button1.Height + 5);
            button2.BackColor = Color.FromArgb(65, 105, 225);
            button2.Click += Button_Click;

        }

        public void Gen_Panel(int k = 0)
        {
            int h1 = k * 300;
            int h2 = k * 25;

            Label l = Create_Label(this, "l", "Текст вопроса № " + k, new Point(this.Width / 2 - 390, this.Height / 3 - 470 + h1));
            TextBox tb = Create_TextBox(this, "tb", new Point(l.Location.X, l.Location.Y + 20), new Size(Convert.ToInt32(this.Size.Width / 1.2) - 35, this.Height / 6));

            Button add = Create_Button(this, "bt_add_variants", "Добавить вариант ответа", new Point(tb.Location.X + tb.Width / 2, tb.Location.Y + tb.Height + 20));
            add.Location = new Point(tb.Location.X + tb.Width / 2 - add.Width / 2, tb.Location.Y + tb.Height/2 + 15);
            add.ForeColor = Color.FromArgb(65, 105, 225);
            add.Anchor = AnchorStyles.None;

            Label label = Create_Label(this, "label" + k, "Вариант ответа:", new Point(tb.Location.X, tb.Location.Y + tb.Height + 10));
            TextBox textBox = Create_TextBox(this, "textBox" + k, new Point(label.Location.X + label.Width, label.Location.Y), new Size(Convert.ToInt32(this.Size.Width / 1.6) - 35, 20));
            Label label2 = Create_Label(this, "label2" + k, "Баллы", new Point(textBox.Location.X + textBox.Width, textBox.Location.Y));
            TextBox textBox2 = Create_TextBox(this, "textBox2" + k, new Point(label2.Location.X + label2.Width, label2.Location.Y), new Size(label2.Width, 20));
            
            add.Location = new Point(add.Location.X, add.Location.Y + 25 + h2);

            Button _add = Create_Button(this, "add_questions", "Добавить вопрос", new Point(add.Location.X, add.Location.Y + add.Height));
            _add.Location = new Point(add.Location.X - _add.Width / 2 + add.Width / 2, add.Location.Y + add.Height + 5);
            _add.ForeColor = Color.FromArgb(65, 105, 225);
            _add.Anchor = AnchorStyles.None;

            Button btresult = Create_Button(this, "btresult", "Перейти к редактированию результатов", new Point(_add.Location.X, _add.Location.Y + _add.Height));
            btresult.Location = new Point(_add.Location.X - btresult.Width / 2 + _add.Width / 2, _add.Location.Y + _add.Height + 10);
            btresult.BackColor = Color.FromArgb(65, 105, 225);
            btresult.Anchor = AnchorStyles.None;
            btresult.Click += Button_Click;
            _add.Click += Button_Click;
            add.Click += Button_Click;

            /*
			add.Click += Add_Click;

			void Add_Click(object sender, EventArgs e)
            {
				Button b = (Button)sender;

				if(b.Name == "add")
                {
					for(int i = 10 * 3; i < 40 * 3; i+=10*3)
                    {
						Panel panel = Create_Panel(clone, "panel", new Point(tb.Width / 2 - 150, tb.Height / 3 + 130 + i), new Size(tb.Width, add.Height + 5));
						panel.BorderStyle = BorderStyle.FixedSingle;
						Label label = Create_Label(panel, "label" + k, "Вариант ответа:", new Point(panel.Location.X - 5, panel.Location.Y + panel.Height + 10));
						TextBox textBox = Create_TextBox(panel, "textBox" + k, new Point(label.Location.X + label.Width, label.Location.Y), new Size(210, 20));
						Label label2 = Create_Label(panel, "label2" + k, "Баллы", new Point(textBox.Location.X + textBox.Width, textBox.Location.Y));
						TextBox textBox2 = Create_TextBox(panel, "textBox2" + k, new Point(label2.Location.X + label2.Width, label2.Location.Y), new Size(label2.Width, 20));
					}						
					add.Location = new Point(add.Location.X, add.Location.Y + 30 * 3);
					clone.Height += 35 * 3;
			
				}
            }

            */
        }

        public Panel Create_Panel(Control c, string name, Point pos, Size sz)
        {
            Panel p = new Panel();
            p.Name = name;
            p.Location = pos;
            p.BorderStyle = BorderStyle.None;
            p.Size = sz;
            c.Controls.Add(p);
            return p;
        }

        public Label Create_Label(Control c, string name, string text, Point pos)
        {
            Label lb = new Label();
            lb.Name = name;
            lb.Text = text;
            lb.Location = pos;
            lb.AutoSize = true;
            c.Controls.Add(lb);
            return lb;
        }

        public TextBox Create_TextBox(Control c, string name, Point pos, Size sz)
        {
            TextBox tb = new TextBox();
            tb.Name = name;
            tb.Location = pos;
            tb.Multiline = true;
            tb.Size = sz;
            c.Controls.Add(tb);
            return tb;

        }

        public Button Create_Button(Control c, string name, string text, Point pos)
        {
            Button bt = new Button();
            bt.Text = text;
            bt.Name = name;
            bt.Location = pos;
            bt.AutoSize = true;
            c.Controls.Add(bt);
            return bt;
        }


    }
}